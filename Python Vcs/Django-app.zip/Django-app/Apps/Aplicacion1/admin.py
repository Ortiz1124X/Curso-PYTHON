from django.contrib import admin
from .models import Director

# Register your models here.

admin.site.register(Director)
